import React, { useEffect } from 'react';
import { useLanguage } from '../context/LanguageContext';

export type AppTab = 'database' | 'calculator' | 'rotation' | 'safety' | 'guidebook' | 'alerts';

const THEME_COLOR: Record<AppTab, string> = {
  database: '#059669',
  calculator: '#0f766e',
  rotation: '#2563eb',
  safety: '#d97706',
  guidebook: '#166534',
  alerts: '#e11d48'
};

const TAB_META: Record<AppTab, { en: { title: string; description: string }; bn: { title: string; description: string } }> = {
  database: {
    en: {
      title: 'AgriChem Pro — Chemical Database',
      description: 'Search DAE-registered pesticides by crop, pest, trade name, and MoA code.'
    },
    bn: {
      title: 'এগ্রিকেম প্রো — রাসায়নিক ডাটাবেস',
      description: 'ফসল, বালাই, ট্রেড নাম ও MoA কোড দিয়ে ডিএই নিবন্ধিত বালাইনাশক খুঁজুন।'
    }
  },
  calculator: {
    en: {
      title: 'AgriChem Pro — Dosage Calculator',
      description: 'Knapsack tank-mix rates, water volume, and field area conversions.'
    },
    bn: {
      title: 'এগ্রিকেম প্রো — মাত্রা ক্যালকুলেটর',
      description: 'ন্যাপস্যাক ট্যাংক মিক্স, পানির পরিমাণ ও জমির আয়তন হিসাব করুন।'
    }
  },
  rotation: {
    en: {
      title: 'AgriChem Pro — MoA Rotation Planner',
      description: 'Build IRAC, FRAC, and HRAC spray sequences that break resistance.'
    },
    bn: {
      title: 'এগ্রিকেম প্রো — MoA ঘূর্ণন পরিকল্পনা',
      description: 'প্রতিরোধ ভাঙতে IRAC, FRAC ও HRAC স্প্রে ক্রম তৈরি করুন।'
    }
  },
  safety: {
    en: {
      title: 'AgriChem Pro — Safety & PPE',
      description: 'WHO hazard bands, pre-spray PPE checklist, and first-aid protocols.'
    },
    bn: {
      title: 'এগ্রিকেম প্রো — নিরাপত্তা ও পিপিই',
      description: 'ডব্লিউএইচও বিপদ ব্যান্ড, স্প্রে-পূর্ব পিপিই চেকলিস্ট ও প্রাথমিক চিকিৎসা।'
    }
  },
  guidebook: {
    en: {
      title: 'AgriChem Pro — Pocket Book Guide',
      description: 'Download the A5 field pocket book: calibration, W.A.L.E.S., PHI, and crop tables.'
    },
    bn: {
      title: 'এগ্রিকেম প্রো — পকেট বুক গাইড',
      description: 'A5 পকেট বুক ডাউনলোড করুন: ক্যালিব্রেশন, W.A.L.E.S., PHI ও ফসলভিত্তিক তালিকা।'
    }
  },
  alerts: {
    en: {
      title: 'AgriChem Pro — Regulatory Alerts',
      description: 'Seasonal pest warnings, restricted-use notices, and harvest-interval reminders.'
    },
    bn: {
      title: 'এগ্রিকেম প্রো — নিয়ন্ত্রক সতর্কবার্তা',
      description: 'মৌসুমী বালাই সতর্কতা, নিষেধাজ্ঞা ও ফসল তোলার বিরতি স্মারক।'
    }
  }
};

function upsertMeta(selector: string, attrs: Record<string, string>, createTag: 'meta' | 'link' = 'meta') {
  let el = document.head.querySelector(selector) as HTMLMetaElement | HTMLLinkElement | null;
  if (!el) {
    el = document.createElement(createTag);
    const [[key, value]] = Object.entries(attrs);
    el.setAttribute(key, value);
    document.head.appendChild(el);
  }
  Object.entries(attrs).forEach(([key, value]) => {
    if (el && el.getAttribute(key) !== value) {
      el.setAttribute(key, value);
    }
  });
  return el;
}

function setNamedMeta(attr: 'name' | 'property', key: string, content: string) {
  upsertMeta(`meta[${attr}="${key}"]`, { [attr]: key, content });
}

function absUrl(path: string) {
  if (typeof window === 'undefined') return path;
  try {
    return new URL(path, window.location.origin).href;
  } catch {
    return path;
  }
}

export const DocumentMeta: React.FC<{ activeTab: AppTab }> = ({ activeTab }) => {
  const { language } = useLanguage();

  useEffect(() => {
    const copy = TAB_META[activeTab][language];
    const appName = language === 'bn' ? 'এগ্রিকেম প্রো' : 'AgriChem Pro';
    const theme = THEME_COLOR[activeTab];
    const iconPng = `/icons/apple-touch-${activeTab}.png`;
    const iconSvg = `/icons/apple-touch-${activeTab}.svg`;
    const ogImage = language === 'bn' ? '/icons/og-bn.svg' : '/icons/og-en.svg';
    const ogImageAbs = absUrl(ogImage);

    document.title = copy.title;
    document.documentElement.lang = language === 'bn' ? 'bn' : 'en';

    setNamedMeta('name', 'description', copy.description);
    setNamedMeta('name', 'application-name', appName);
    setNamedMeta('name', 'apple-mobile-web-app-title', appName);
    setNamedMeta('name', 'apple-mobile-web-app-capable', 'yes');
    setNamedMeta('name', 'mobile-web-app-capable', 'yes');
    setNamedMeta('name', 'apple-mobile-web-app-status-bar-style', 'black-translucent');
    setNamedMeta('name', 'theme-color', theme);
    setNamedMeta('name', 'msapplication-TileColor', theme);
    setNamedMeta('name', 'msapplication-TileImage', iconPng);

    setNamedMeta('property', 'og:title', copy.title);
    setNamedMeta('property', 'og:description', copy.description);
    setNamedMeta('property', 'og:type', 'website');
    setNamedMeta('property', 'og:locale', language === 'bn' ? 'bn_BD' : 'en_US');
    setNamedMeta('property', 'og:site_name', appName);
    setNamedMeta('property', 'og:image', ogImageAbs);
    setNamedMeta('property', 'og:image:alt', appName);

    setNamedMeta('name', 'twitter:card', 'summary_large_image');
    setNamedMeta('name', 'twitter:title', copy.title);
    setNamedMeta('name', 'twitter:description', copy.description);
    setNamedMeta('name', 'twitter:image', ogImageAbs);

    upsertMeta('link[rel="icon"][type="image/svg+xml"]', { rel: 'icon', type: 'image/svg+xml', href: iconSvg }, 'link');
    upsertMeta('link[rel="icon"][type="image/png"]', { rel: 'icon', type: 'image/png', sizes: '32x32', href: '/favicon-32.png' }, 'link');
    upsertMeta('link[rel="apple-touch-icon"]', { rel: 'apple-touch-icon', sizes: '180x180', href: `${iconPng}?v=${activeTab}` }, 'link');
    upsertMeta('link[rel="mask-icon"]', { rel: 'mask-icon', href: '/favicon.svg', color: theme }, 'link');
    upsertMeta('link[rel="manifest"]', { rel: 'manifest', href: '/site.webmanifest' }, 'link');
    upsertMeta('link[rel="canonical"]', { rel: 'canonical', href: absUrl(window.location.pathname || '/') }, 'link');

    document.documentElement.style.setProperty('--app-theme', theme);
  }, [activeTab, language]);

  return null;
};
