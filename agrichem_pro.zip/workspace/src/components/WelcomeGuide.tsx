import React, { useEffect, useState } from 'react';
import { BookOpen, Calculator, RotateCw, ShieldCheck, Database, X, Compass } from 'lucide-react';
import { useLanguage } from '../context/LanguageContext';

const STORAGE_KEY = 'agrichem_welcome_seen';

interface WelcomeGuideProps {
  forceOpen?: boolean;
  onDismiss?: () => void;
  onGo: (tab: 'database' | 'calculator' | 'rotation' | 'safety' | 'guidebook') => void;
}

export const WelcomeGuide: React.FC<WelcomeGuideProps> = ({ forceOpen = false, onDismiss, onGo }) => {
  const { language } = useLanguage();
  const [open, setOpen] = useState(false);

  useEffect(() => {
    if (forceOpen) {
      setOpen(true);
      return;
    }
    if (typeof window === 'undefined') return;
    const seen = localStorage.getItem(STORAGE_KEY);
    if (!seen) setOpen(true);
  }, [forceOpen]);

  const close = () => {
    setOpen(false);
    if (typeof window !== 'undefined') {
      localStorage.setItem(STORAGE_KEY, '1');
    }
    onDismiss?.();
  };

  const go = (tab: 'database' | 'calculator' | 'rotation' | 'safety' | 'guidebook') => {
    close();
    onGo(tab);
  };

  if (!open) return null;

  const steps = language === 'bn'
    ? [
        { id: 'database' as const, icon: Database, title: '১. খুঁজুন', body: 'ফসল, বালাই বা ট্রেড নাম দিয়ে নিবন্ধিত বালাইনাশক দেখুন।' },
        { id: 'calculator' as const, icon: Calculator, title: '২. হিসাব করুন', body: 'জমির আয়তন অনুযায়ী ট্যাংক মিক্স ও পানির পরিমাণ বের করুন।' },
        { id: 'rotation' as const, icon: RotateCw, title: '৩. ঘোরান', body: 'একই MoA বারবার ব্যবহার না করে প্রতিরোধ রোধ করুন।' },
        { id: 'safety' as const, icon: ShieldCheck, title: '৪. সুরক্ষা', body: 'স্প্রে করার আগে পিপিই ও নিরাপত্তা চেকলিস্ট সম্পন্ন করুন।' },
        { id: 'guidebook' as const, icon: BookOpen, title: '৫. পকেট বুক', body: 'অফলাইন A5 গাইড ডাউনলোড করে মাঠে নিয়ে যান।' }
      ]
    : [
        { id: 'database' as const, icon: Database, title: '1. Search', body: 'Look up registered products by crop, pest, or trade name.' },
        { id: 'calculator' as const, icon: Calculator, title: '2. Calculate', body: 'Convert field area into knapsack tank mix and water volume.' },
        { id: 'rotation' as const, icon: RotateCw, title: '3. Rotate', body: 'Alternate MoA codes so pests do not build resistance.' },
        { id: 'safety' as const, icon: ShieldCheck, title: '4. Stay safe', body: 'Complete the PPE checklist before every spray.' },
        { id: 'guidebook' as const, icon: BookOpen, title: '5. Pocket book', body: 'Download the A5 field guide for offline use.' }
      ];

  return (
    <div
      className="fixed inset-0 z-50 flex items-end sm:items-center justify-center p-4 bg-slate-900/45"
      role="dialog"
      aria-modal="true"
      aria-labelledby="welcome-guide-title"
    >
      <div className="w-full max-w-lg bg-[#f7f6f1] rounded-2xl shadow-xl border border-stone-200 overflow-hidden">
        <div className="px-5 pt-5 pb-3 flex items-start justify-between gap-3">
          <div>
            <p className="text-[11px] font-semibold uppercase tracking-wider text-emerald-800">
              {language === 'bn' ? 'সংক্ষিপ্ত সূচনা' : 'Quick start'}
            </p>
            <h2 id="welcome-guide-title" className="text-lg font-bold text-slate-900 mt-0.5">
              {language === 'bn' ? 'এই অ্যাপ কীভাবে ব্যবহার করবেন' : 'How to use this guide'}
            </h2>
            <p className="text-sm text-slate-600 mt-1 leading-relaxed">
              {language === 'bn'
                ? 'জ্ঞান ভাগ করে নেওয়ার জন্য তৈরি। চূড়ান্ত সিদ্ধান্ত নিন কৃষি সম্প্রসারণ অধিদপ্তর (DAE) বা স্থানীয় কৃষি কর্মকর্তার পরামর্শে।'
                : 'Built for knowledge sharing. Take final advice from DAE or your local extension officer.'}
            </p>
          </div>
          <button
            type="button"
            onClick={close}
            className="shrink-0 min-w-11 min-h-11 inline-flex items-center justify-center rounded-xl text-slate-500 hover:bg-stone-200/80 cursor-pointer"
            aria-label={language === 'bn' ? 'বন্ধ করুন' : 'Close'}
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        <ol className="px-4 pb-2 space-y-1.5">
          {steps.map((step) => {
            const Icon = step.icon;
            return (
              <li key={step.id}>
                <button
                  type="button"
                  onClick={() => go(step.id)}
                  className="w-full text-left flex items-start gap-3 rounded-xl px-3 py-2.5 hover:bg-white border border-transparent hover:border-stone-200 transition cursor-pointer"
                >
                  <span className="mt-0.5 w-9 h-9 rounded-lg bg-emerald-700 text-white flex items-center justify-center shrink-0">
                    <Icon className="w-4 h-4" />
                  </span>
                  <span>
                    <span className="block text-sm font-semibold text-slate-900">{step.title}</span>
                    <span className="block text-xs text-slate-600 leading-relaxed mt-0.5">{step.body}</span>
                  </span>
                </button>
              </li>
            );
          })}
        </ol>

        <div className="px-5 py-4 border-t border-stone-200 flex flex-wrap items-center justify-between gap-3">
          <p className="text-[11px] text-slate-500 flex items-center gap-1.5">
            <Compass className="w-3.5 h-3.5" />
            {language === 'bn' ? 'পণ্যের লেবেল সবসময় প্রাধান্য পাবে।' : 'The product label always comes first.'}
          </p>
          <button
            type="button"
            onClick={close}
            className="min-h-11 px-4 rounded-xl bg-emerald-800 hover:bg-emerald-900 text-white text-sm font-semibold cursor-pointer"
          >
            {language === 'bn' ? 'বুঝেছি, শুরু করি' : 'Got it, start exploring'}
          </button>
        </div>
      </div>
    </div>
  );
};
