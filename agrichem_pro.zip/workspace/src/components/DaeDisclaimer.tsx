import React, { useState } from 'react';
import { Info } from 'lucide-react';
import { useLanguage } from '../context/LanguageContext';

interface DaeDisclaimerProps {
  onOpenGuide: () => void;
}

export const DaeDisclaimer: React.FC<DaeDisclaimerProps> = ({ onOpenGuide }) => {
  const { language } = useLanguage();
  const [expanded, setExpanded] = useState(false);

  return (
    <aside
      className="border-t border-amber-200/80 bg-amber-50 text-amber-950"
      aria-label={language === 'bn' ? 'DAE ডিসক্লেইমার' : 'DAE disclaimer'}
    >
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-3">
        <div className="flex items-start gap-3">
          <Info className="w-4 h-4 mt-0.5 text-amber-800 shrink-0" aria-hidden="true" />
          <div className="flex-1 min-w-0">
            <p className="text-xs sm:text-sm leading-relaxed">
              <strong className="font-semibold">
                {language === 'bn' ? 'জ্ঞান ভাগাভাগির উদ্দেশ্যে। ' : 'For knowledge sharing only. '}
              </strong>
              {language === 'bn'
                ? 'এটি DAE-এর অফিসিয়াল আদেশ নয়। স্প্রে, মাত্রা বা নিষেধাজ্ঞার চূড়ান্ত সিদ্ধান্ত নিন পণ্যের লেবেল এবং কৃষি সম্প্রসারণ অধিদপ্তর (DAE) বা উপজেলা কৃষি কর্মকর্তার পরামর্শে।'
                : 'This is not an official DAE order. For spray, dose, or restriction decisions, follow the product label and take final advice from the Department of Agricultural Extension (DAE) or your upazila agriculture officer.'}
            </p>
            {expanded && (
              <p className="text-xs text-amber-900/90 mt-2 leading-relaxed">
                {language === 'bn'
                  ? 'তথ্য শিক্ষামূলক রেফারেন্স হিসেবে সংকলিত। নিবন্ধন, PHI, REI বা নিষিদ্ধ তালিকা পরিবর্তন হতে পারে। প্রয়োগের আগে সর্বশেষ DAE তালিকা ও লেবেল মিলিয়ে নিন। ভুল প্রয়োগ, ফসল ক্ষতি বা আইনগত ফলাফলের দায় এই অ্যাপের নয়।'
                  : 'Figures here are educational references. Registration, PHI, REI, and banned lists can change. Cross-check the latest DAE list and the printed label before any application. This app is not liable for misuse, crop injury, or legal outcomes.'}
              </p>
            )}
            <div className="mt-2 flex flex-wrap items-center gap-3">
              <button
                type="button"
                onClick={() => setExpanded((v) => !v)}
                className="text-xs font-semibold text-amber-950 underline underline-offset-2 cursor-pointer min-h-9"
              >
                {expanded
                  ? (language === 'bn' ? 'কম দেখুন' : 'Show less')
                  : (language === 'bn' ? 'পূর্ণ ডিসক্লেইমার' : 'Full disclaimer')}
              </button>
              <button
                type="button"
                onClick={onOpenGuide}
                className="text-xs font-semibold text-emerald-900 underline underline-offset-2 cursor-pointer min-h-9"
              >
                {language === 'bn' ? 'কীভাবে ব্যবহার করবেন' : 'How to use this app'}
              </button>
            </div>
          </div>
        </div>
      </div>
    </aside>
  );
};

export const reopenWelcomeGuide = () => {
  if (typeof window !== 'undefined') {
    localStorage.removeItem('agrichem_welcome_seen');
  }
};
