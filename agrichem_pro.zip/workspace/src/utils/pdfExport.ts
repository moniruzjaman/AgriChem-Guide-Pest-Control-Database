import { ChemicalProduct, DosageResult, DosageInput, SprayRotationStep } from '../types';

// Lazy loader for PDF generation libraries to prevent heavy upfront evaluation
async function loadPdfEngines() {
  const [{ default: jsPDF }, { default: autoTable }] = await Promise.all([
    import('jspdf'),
    import('jspdf-autotable')
  ]);
  return { jsPDF, autoTable };
}

export async function exportSingleProductPDF(product: ChemicalProduct) {
  const { jsPDF, autoTable } = await loadPdfEngines();
  const doc = new jsPDF();

  // Header Banner
  doc.setFillColor(22, 101, 52); // Forest Green
  doc.rect(0, 0, 210, 28, 'F');

  doc.setTextColor(255, 255, 255);
  doc.setFontSize(16);
  doc.setFont('helvetica', 'bold');
  doc.text('AGRICHEM FIELD GUIDE & SAFETY SUMMARY', 14, 12);
  doc.setFontSize(10);
  doc.setFont('helvetica', 'normal');
  doc.text('Agricultural Chemical Controls Guidebook - Field Reference Dossier', 14, 20);

  // Document metadata
  doc.setTextColor(100, 100, 100);
  doc.setFontSize(8);
  doc.text(`Generated: ${new Date().toLocaleDateString()} | Registration: ${product.registrationNo}`, 14, 34);

  // Product title
  doc.setTextColor(20, 20, 20);
  doc.setFontSize(18);
  doc.setFont('helvetica', 'bold');
  doc.text(product.tradeName, 14, 44);

  doc.setFontSize(11);
  doc.setFont('helvetica', 'normal');
  doc.setTextColor(70, 70, 70);
  doc.text(`Active Ingredient: ${product.commonName} | Category: ${product.type}`, 14, 51);

  // Basic Info Table
  autoTable(doc, {
    startY: 56,
    head: [['Field Property', 'Specification / Registered Detail']],
    body: [
      ['Trade Name of Product', product.tradeName],
      ['Common Active Ingredient', product.commonName],
      ['Pesticide Category', product.type],
      ['Registration Number', product.registrationNo],
      ['Registration Holder / Company', product.registrationHolder],
      ['Registered Dosage Rate', product.dosageRate],
      ['Recommended Crops', product.crops.join(', ')],
      ['Target Pests & Diseases', product.pests.join(', ')],
      ['Formulation Type', product.formulation || 'Liquid / Powder / Granule'],
      ['Mode of Action (MoA)', `${product.moaCode || 'Standard'} - ${product.moaGroup || 'Target site specified'}`],
      ['Resistance Risk Assessment', `${product.resistanceRisk || 'Medium'} Risk`],
      ['Pre-Harvest Interval (PHI)', product.phiDays ? `${product.phiDays} Days before harvesting` : 'Follow crop label'],
      ['Restricted Entry Interval (REI)', product.reiHours ? `${product.reiHours} Hours` : '24 Hours after spray']
    ],
    theme: 'striped',
    headStyles: { fillColor: [22, 101, 52], textColor: 255, fontStyle: 'bold' },
    styles: { fontSize: 9, cellPadding: 3 }
  });

  // Safety & Resistance Section
  const currentY = (doc as any).lastAutoTable.finalY + 8;

  doc.setFontSize(12);
  doc.setFont('helvetica', 'bold');
  doc.setTextColor(22, 101, 52);
  doc.text('RESISTANCE ROTATION & FIELD SAFETY CHECKLIST', 14, currentY);

  autoTable(doc, {
    startY: currentY + 4,
    head: [['Category', 'Official Guidance & Precaution']],
    body: [
      ['Resistance Strategy', product.rotationNotes || 'Rotate with an active ingredient from a different MoA group. Never spray more than 2 consecutive applications.'],
      ['Personal Protective Equipment', 'Wear nitrile/rubber gloves, vapor respirator or dust mask, safety goggles, long-sleeved overalls, and rubber gumboots.'],
      ['Environmental Precaution', 'Do NOT spray during strong winds (>10 km/h) or direct sun. Avoid drift to bee apiaries and keep 15m buffer from water bodies.'],
      ['Container Disposal', 'Triple-rinse empty chemical containers into the spray tank. Puncture container bottom to prevent reuse and dispose safely according to local rules.']
    ],
    theme: 'grid',
    headStyles: { fillColor: [30, 41, 59], textColor: 255 },
    styles: { fontSize: 8.5, cellPadding: 3.5 }
  });

  // Footer
  const pageHeight = doc.internal.pageSize.height;
  doc.setFontSize(8);
  doc.setTextColor(130, 130, 130);
  doc.text('AgriChem Guidebook - Department of Agricultural Extension / Agricultural Field Reference.', 14, pageHeight - 8);

  doc.save(`${product.tradeName.replace(/[^a-zA-Z0-9]/g, '_')}_Field_Guide.pdf`);
}

export async function exportCropGuidePDF(cropName: string, products: ChemicalProduct[]) {
  const { jsPDF, autoTable } = await loadPdfEngines();
  const doc = new jsPDF('landscape');

  // Header Banner
  doc.setFillColor(22, 101, 52);
  doc.rect(0, 0, 297, 24, 'F');

  doc.setTextColor(255, 255, 255);
  doc.setFontSize(15);
  doc.setFont('helvetica', 'bold');
  doc.text(`AGRICHEM PEST & DISEASE CONTROL SUMMARY: ${cropName.toUpperCase()}`, 14, 11);
  doc.setFontSize(9);
  doc.setFont('helvetica', 'normal');
  doc.text(`Official Registered Agricultural Controls & MoA Rotation Guide | Generated: ${new Date().toLocaleDateString()}`, 14, 18);

  const tableData = products.map((p) => [
    p.tradeName,
    p.commonName,
    p.type,
    p.pests.join(', '),
    p.dosageRate,
    p.moaCode || 'N/A',
    p.registrationHolder,
    p.phiDays ? `${p.phiDays}d` : '-'
  ]);

  autoTable(doc, {
    startY: 28,
    head: [['Trade Name', 'Active Ingredient', 'Category', 'Target Pests/Diseases', 'Dosage Rate', 'MoA Code', 'Registration Holder', 'PHI']],
    body: tableData,
    theme: 'striped',
    headStyles: { fillColor: [22, 101, 52], textColor: 255, fontStyle: 'bold', fontSize: 8 },
    styles: { fontSize: 7.5, cellPadding: 2.5 },
    columnStyles: {
      0: { fontStyle: 'bold', cellWidth: 36 },
      1: { cellWidth: 38 },
      2: { cellWidth: 24 },
      3: { cellWidth: 60 },
      4: { cellWidth: 38 },
      5: { cellWidth: 26 },
      6: { cellWidth: 44 },
      7: { cellWidth: 14 }
    }
  });

  const pageCount = (doc.internal as any).getNumberOfPages();
  for (let i = 1; i <= pageCount; i++) {
    doc.setPage(i);
    doc.setFontSize(8);
    doc.setTextColor(120, 120, 120);
    doc.text(`Page ${i} of ${pageCount} | AgriChem Guidebook Database`, 14, doc.internal.pageSize.height - 6);
  }

  doc.save(`${cropName.replace(/\s+/g, '_')}_Pest_Control_Guide.pdf`);
}

export async function exportDosagePrescriptionPDF(
  product: ChemicalProduct,
  input: DosageInput,
  result: DosageResult
) {
  const { jsPDF, autoTable } = await loadPdfEngines();
  const doc = new jsPDF();

  // Header Banner
  doc.setFillColor(15, 118, 110); // Teal
  doc.rect(0, 0, 210, 28, 'F');

  doc.setTextColor(255, 255, 255);
  doc.setFontSize(16);
  doc.setFont('helvetica', 'bold');
  doc.text('FIELD DOSAGE & TANK MIX PRESCRIPTION', 14, 12);
  doc.setFontSize(9);
  doc.setFont('helvetica', 'normal');
  doc.text('Precision Agricultural Application & Sprayer Calibration Report', 14, 20);

  // Field & Chemical Spec
  autoTable(doc, {
    startY: 34,
    head: [['Parameter', 'Field Value']],
    body: [
      ['Target Chemical', `${product.tradeName} (${product.commonName})`],
      ['Chemical Category & MoA', `${product.type} | ${product.moaCode || 'Standard'}`],
      ['Registration Number', product.registrationNo],
      ['Field Application Area', `${input.areaValue} ${input.areaUnit.toUpperCase()} (${result.convertedHa} Ha / ${result.convertedAcres} Acres)`],
      ['Knapsack Sprayer Tank Volume', `${input.tankVolumeL} Litres`],
      ['Total Water Volume Needed', `${result.totalWaterNeededL} Litres`],
      ['Number of Spray Tanks', `${result.numberOfTanks} Tanks`],
      ['TOTAL CHEMICAL REQUIRED', result.totalChemicalNeeded],
      ['CHEMICAL PER SPRAY TANK', result.chemicalPerTank],
      ['Application Notes', result.notes]
    ],
    theme: 'grid',
    headStyles: { fillColor: [15, 118, 110], textColor: 255 },
    styles: { fontSize: 9, cellPadding: 3.5 },
    columnStyles: {
      0: { fontStyle: 'bold', cellWidth: 70 }
    }
  });

  const nextY = (doc as any).lastAutoTable.finalY + 8;
  doc.setFontSize(11);
  doc.setFont('helvetica', 'bold');
  doc.setTextColor(15, 118, 110);
  doc.text('SPRAYER CALIBRATION & PPE CHECKLIST', 14, nextY);

  autoTable(doc, {
    startY: nextY + 4,
    head: [['Step', 'Field Operation Protocol']],
    body: [
      ['1. Tank Pre-Mix', 'Fill knapsack sprayer half-full with clean water. Pre-dissolve measured chemical in a separate plastic jug with clean water before pouring into tank.'],
      ['2. Agitation & Fill', 'Add remainder of water up to the measured mark. Agitate gently to achieve homogenous suspension.'],
      ['3. Nozzle & Pressure', 'Use hollow-cone nozzles for insecticides/fungicides or floodjet/flat-fan nozzles for herbicides. Check for nozzle leaks or clogged tips.'],
      ['4. Wind & Weather', 'Apply during calm morning (7:00-10:00 AM) or late afternoon (4:00-6:30 PM). Never spray during wind >10 km/h or high heat.'],
      ['5. PPE Reminder', 'Wear chemical-resistant gloves, protective goggles, long trousers, and respirator mask during both mixing and spraying.'],
      ['6. Harvest Interval', `Respect Pre-Harvest Interval (PHI) of ${product.phiDays || 14} days before harvesting.`]
    ],
    theme: 'striped',
    headStyles: { fillColor: [51, 65, 85], textColor: 255 },
    styles: { fontSize: 8.5, cellPadding: 3 }
  });

  doc.save(`${product.tradeName}_Dosage_Prescription.pdf`);
}

export async function exportRotationSchedulePDF(crop: string, pest: string, steps: SprayRotationStep[]) {
  const { jsPDF, autoTable } = await loadPdfEngines();
  const doc = new jsPDF();

  doc.setFillColor(30, 64, 175); // Royal Blue
  doc.rect(0, 0, 210, 28, 'F');

  doc.setTextColor(255, 255, 255);
  doc.setFontSize(16);
  doc.setFont('helvetica', 'bold');
  doc.text('ANTI-RESISTANCE ROTATION SCHEDULE', 14, 12);
  doc.setFontSize(9);
  doc.setFont('helvetica', 'normal');
  doc.text(`Crop: ${crop} | Target Pest/Disease: ${pest} | IRAC/FRAC/HRAC Sequence`, 14, 20);

  const tableData = steps.map((s) => [
    `Spray #${s.sprayNumber}`,
    s.sprayWindow,
    s.productName,
    s.commonName,
    s.moaCode,
    s.status === 'valid' ? 'Valid Rotation' : 'CONFLICT: Repeated MoA'
  ]);

  autoTable(doc, {
    startY: 34,
    head: [['Spray #', 'Application Window', 'Trade Name', 'Active Ingredient', 'MoA Code', 'Resistance Status']],
    body: tableData,
    theme: 'grid',
    headStyles: { fillColor: [30, 64, 175], textColor: 255 },
    styles: { fontSize: 8.5, cellPadding: 3.5 }
  });

  doc.save(`${crop}_${pest}_Rotation_Schedule.pdf`);
}

const POCKET_GREEN: [number, number, number] = [22, 101, 52];
const POCKET_SLATE: [number, number, number] = [15, 23, 42];
const POCKET_TEAL: [number, number, number] = [8, 145, 178];
const POCKET_AMBER: [number, number, number] = [146, 64, 14];

function addPocketHeader(doc: any, title: string) {
  doc.setFillColor(...POCKET_GREEN);
  doc.rect(0, 0, 148, 12, 'F');
  doc.setTextColor(255, 255, 255);
  doc.setFontSize(8);
  doc.setFont('helvetica', 'bold');
  doc.text(title, 8, 8);
}

function addPocketFooter(doc: any, page: number, total: number) {
  const h = doc.internal.pageSize.height;
  doc.setFillColor(...POCKET_SLATE);
  doc.rect(0, h - 8, 148, 8, 'F');
  doc.setTextColor(226, 232, 240);
  doc.setFontSize(6.5);
  doc.setFont('helvetica', 'normal');
  doc.text('AgriChem Pro Pocket Book  |  Field use only — always read the product label', 8, h - 3.2);
  doc.text(`${page}/${total}`, 138, h - 3.2, { align: 'right' });
}

function wrapPocketText(doc: any, text: string, x: number, y: number, maxWidth: number, lineHeight = 3.4) {
  const lines = doc.splitTextToSize(text, maxWidth);
  doc.text(lines, x, y);
  return y + lines.length * lineHeight;
}

export async function exportPocketBookPDF(products: ChemicalProduct[]) {
  const { jsPDF, autoTable } = await loadPdfEngines();
  const doc = new jsPDF({ orientation: 'portrait', unit: 'mm', format: 'a5' });
  const generated = new Date().toLocaleDateString();
  const cropsList = ['Rice', 'Potato', 'Mango', 'Tea', 'Brinjal', 'Tomato', 'Jute'];

  const uniqueActives = Array.from(new Set(products.map((p) => p.commonName)));
  const typeCounts = {
    Insecticide: products.filter((p) => p.type === 'Insecticide').length,
    Fungicide: products.filter((p) => p.type === 'Fungicide').length,
    Herbicide: products.filter((p) => p.type === 'Herbicide').length,
    Other: products.filter((p) => !['Insecticide', 'Fungicide', 'Herbicide'].includes(p.type)).length
  };

  // ---------- COVER ----------
  doc.setFillColor(...POCKET_GREEN);
  doc.rect(0, 0, 148, 210, 'F');
  doc.setFillColor(6, 78, 59);
  doc.rect(0, 0, 148, 28, 'F');
  doc.setFillColor(15, 23, 42);
  doc.rect(0, 182, 148, 28, 'F');

  doc.setTextColor(167, 243, 208);
  doc.setFontSize(8);
  doc.setFont('helvetica', 'bold');
  doc.text('FIELD POCKET MANUAL  ·  A5  ·  OFFLINE READY', 74, 16, { align: 'center' });

  doc.setTextColor(255, 255, 255);
  doc.setFontSize(22);
  doc.setFont('helvetica', 'bold');
  doc.text('AGRICHEM PRO', 74, 72, { align: 'center' });
  doc.setFontSize(11);
  doc.setFont('helvetica', 'normal');
  doc.text('Pest & Disease Controls', 74, 82, { align: 'center' });
  doc.text('Pocket Book Guide', 74, 90, { align: 'center' });

  doc.setDrawColor(167, 243, 208);
  doc.setLineWidth(0.4);
  doc.line(44, 98, 104, 98);

  doc.setFontSize(8);
  doc.setTextColor(209, 250, 229);
  doc.text('Calibration  ·  W.A.L.E.S. Mix  ·  PPE  ·  PHI', 74, 108, { align: 'center' });
  doc.text('Crop spray tables  ·  MoA rotation codes', 74, 114, { align: 'center' });

  doc.setFillColor(255, 255, 255);
  doc.roundedRect(22, 128, 104, 36, 2, 2, 'F');
  doc.setTextColor(...POCKET_SLATE);
  doc.setFontSize(8);
  doc.setFont('helvetica', 'bold');
  doc.text(`${products.length} registered products`, 74, 140, { align: 'center' });
  doc.setFont('helvetica', 'normal');
  doc.setFontSize(7.5);
  doc.text(`${uniqueActives.length} active ingredients  ·  ${cropsList.length} crop tables`, 74, 147, { align: 'center' });
  doc.text(`IRAC / FRAC / HRAC rotation ready`, 74, 154, { align: 'center' });

  doc.setTextColor(148, 163, 184);
  doc.setFontSize(7);
  doc.text(`Generated ${generated}`, 74, 194, { align: 'center' });
  doc.text('Department of Agricultural Extension (DAE) reference data', 74, 200, { align: 'center' });

  // ---------- HOW TO USE ----------
  doc.addPage();
  addPocketHeader(doc, '01  HOW TO USE THIS POCKET BOOK');
  doc.setTextColor(...POCKET_SLATE);
  doc.setFontSize(11);
  doc.setFont('helvetica', 'bold');
  doc.text('Keep this booklet in the spray bag.', 8, 20);
  doc.setFontSize(8);
  doc.setFont('helvetica', 'normal');
  let y = wrapPocketText(
    doc,
    'Print double-sided on A5. Fold or bind. Use crop tables in the field, then confirm dosage with the in-app knapsack calculator before mixing.',
    8,
    26,
    132
  );

  autoTable(doc, {
    startY: y + 4,
    head: [['Section', 'When to open it']],
    body: [
      ['02 Calibration', 'Before first spray of the day'],
      ['03 W.A.L.E.S. mix', 'When tank-mixing 2+ products'],
      ['04 PPE & first aid', 'Before mixing and after exposure'],
      ['05 PHI / REI', 'Before harvest or re-entering field'],
      ['06 Crop tables', 'Choosing a registered product'],
      ['07 MoA codes', 'Planning a rotation sequence']
    ],
    theme: 'striped',
    headStyles: { fillColor: POCKET_GREEN, textColor: 255, fontSize: 7.5, fontStyle: 'bold' },
    styles: { fontSize: 7, cellPadding: 1.8, font: 'helvetica' },
    margin: { left: 8, right: 8 }
  });

  y = (doc as any).lastAutoTable.finalY + 8;
  doc.setFont('helvetica', 'bold');
  doc.setFontSize(9);
  doc.setTextColor(...POCKET_AMBER);
  doc.text('Field rule', 8, y);
  doc.setFont('helvetica', 'normal');
  doc.setTextColor(...POCKET_SLATE);
  doc.setFontSize(8);
  wrapPocketText(
    doc,
    'This pocket book is a field aid, not a substitute for the registered product label. If label rate and this table disagree, follow the label. Never spray without PPE, calibration, and a PHI check.',
    8,
    y + 5,
    132
  );

  // ---------- CALIBRATION ----------
  doc.addPage();
  addPocketHeader(doc, '02  KNAPSACK SPRAYER CALIBRATION');
  doc.setTextColor(...POCKET_SLATE);
  doc.setFontSize(10);
  doc.setFont('helvetica', 'bold');
  doc.text('3-step field method', 8, 20);
  doc.setFontSize(7.5);
  doc.setFont('helvetica', 'normal');

  autoTable(doc, {
    startY: 24,
    head: [['Step', 'Action']],
    body: [
      ['1. Pace', 'Mark 25 m in the crop. Walk your normal spray pace with tank half-full of water. Record seconds (example: 20 s).'],
      ['2. Catch', 'Pump to 2.5–3.0 bar. Catch nozzle output for the same seconds into a jug. Record ml (example: 400 ml).'],
      ['3. Volume', 'L/ha = (Discharge ml × 400) / (Swath m × 1000). Example 0.5 m swath: (400 × 400) / 500 = 320 L/ha.']
    ],
    theme: 'grid',
    headStyles: { fillColor: POCKET_GREEN, textColor: 255, fontSize: 7.5, fontStyle: 'bold' },
    styles: { fontSize: 7, cellPadding: 2, valign: 'top' },
    columnStyles: { 0: { cellWidth: 16, fontStyle: 'bold' }, 1: { cellWidth: 116 } },
    margin: { left: 8, right: 8 }
  });

  y = (doc as any).lastAutoTable.finalY + 6;
  doc.setFont('helvetica', 'bold');
  doc.setFontSize(9);
  doc.text('Nozzle choice', 8, y);
  autoTable(doc, {
    startY: y + 2,
    head: [['Nozzle', 'Use for']],
    body: [
      ['Hollow cone', 'Contact insecticides & fungicides (fine canopy cover)'],
      ['Flat fan', 'Soil / pre-emergence herbicides (even band)'],
      ['Air induction', 'Windy days ~8–10 km/h to cut drift']
    ],
    theme: 'striped',
    headStyles: { fillColor: POCKET_TEAL, textColor: 255, fontSize: 7.5, fontStyle: 'bold' },
    styles: { fontSize: 7, cellPadding: 1.8 },
    margin: { left: 8, right: 8 }
  });

  y = (doc as any).lastAutoTable.finalY + 6;
  doc.setFontSize(7.5);
  doc.setFont('helvetica', 'italic');
  wrapPocketText(
    doc,
    'Never apply uncalibrated. Underdose selects resistance. Overdose burns crop and leaves illegal residues.',
    8,
    y,
    132
  );

  // ---------- WALES ----------
  doc.addPage();
  addPocketHeader(doc, '03  W.A.L.E.S. TANK MIX ORDER');
  doc.setTextColor(...POCKET_SLATE);
  doc.setFontSize(8);
  doc.setFont('helvetica', 'normal');
  wrapPocketText(
    doc,
    'Wrong order curdles mix, clogs nozzles, and deactivates chemistry. Fill tank half with water first. Keep agitating.',
    8,
    20,
    132
  );

  autoTable(doc, {
    startY: 32,
    head: [['', 'Add in this order']],
    body: [
      ['W', 'Wettable powders & granules (WP, WDG, DF). Pre-slurry in a bucket, then pour in.'],
      ['A', 'Agitate thoroughly. Keep mixing from first add until last fill.'],
      ['L', 'Liquid flowables & SCs (SC, SL, F). Water-based products mix smoothly.'],
      ['E', 'Emulsifiable concentrates (EC, EW). Oil last among pesticides — oil coats powder if added too early.'],
      ['S', 'Surfactants, stickers, foliar fertilizers last. Then top up water to mark.']
    ],
    theme: 'grid',
    headStyles: { fillColor: POCKET_TEAL, textColor: 255, fontSize: 7.5, fontStyle: 'bold' },
    styles: { fontSize: 7, cellPadding: 2, valign: 'top' },
    columnStyles: { 0: { cellWidth: 12, fontStyle: 'bold', halign: 'center' }, 1: { cellWidth: 120 } },
    margin: { left: 8, right: 8 }
  });

  y = (doc as any).lastAutoTable.finalY + 8;
  doc.setFont('helvetica', 'bold');
  doc.setFontSize(9);
  doc.text('15-minute jar test', 8, y);
  doc.setFont('helvetica', 'normal');
  doc.setFontSize(7.5);
  wrapPocketText(
    doc,
    'Before a large tank mix, combine proportional amounts in 500 ml water in a clear jar. Wait 15 minutes. Heat, clumps, or oil layers = incompatible. Do not tank-mix.',
    8,
    y + 5,
    132
  );

  // ---------- PPE ----------
  doc.addPage();
  addPocketHeader(doc, '04  PPE CHECKLIST & FIRST AID');
  doc.setTextColor(...POCKET_SLATE);
  doc.setFontSize(9);
  doc.setFont('helvetica', 'bold');
  doc.text('10-point spray-day checklist', 8, 20);

  autoTable(doc, {
    startY: 24,
    head: [['#', 'Check']],
    body: [
      ['1', 'Leak-test tank, hose, lance, gaskets with clean water'],
      ['2', 'Clean nozzles with a brush — never blow by mouth'],
      ['3', 'Wind under 10 km/h; skip heat >32 C and incoming rain'],
      ['4', 'PPE on: nitrile gloves, mask/respirator, goggles, gumboots'],
      ['5', 'Walk upwind or crosswind so mist drifts away from you'],
      ['6', 'No food, drink, or tobacco while mixing or spraying'],
      ['7', '15 m buffer from ponds and bee hives'],
      ['8', 'Triple-rinse empties into tank; puncture to stop reuse'],
      ['9', 'Wash body and spray clothes separately after work'],
      ['10', 'Post REI / PHI warning signs on the field']
    ],
    theme: 'striped',
    headStyles: { fillColor: POCKET_AMBER, textColor: 255, fontSize: 7.5, fontStyle: 'bold' },
    styles: { fontSize: 7, cellPadding: 1.6 },
    columnStyles: { 0: { cellWidth: 10, fontStyle: 'bold', halign: 'center' } },
    margin: { left: 8, right: 8 }
  });

  y = (doc as any).lastAutoTable.finalY + 6;
  doc.setFont('helvetica', 'bold');
  doc.setFontSize(9);
  doc.setTextColor(153, 27, 27);
  doc.text('If exposed', 8, y);
  doc.setFont('helvetica', 'normal');
  doc.setTextColor(...POCKET_SLATE);
  doc.setFontSize(7.5);
  wrapPocketText(
    doc,
    'Skin: remove clothes, wash 15 min with soap and water. Eyes: rinse 15 min. Inhaled: move to fresh air. Swallowed: do not induce vomiting unless a clinician says so. Take the label to the clinic. Organophosphate / carbamate: atropine is the medical antidote — keep the product name ready.',
    8,
    y + 5,
    132
  );

  // ---------- PHI ----------
  doc.addPage();
  addPocketHeader(doc, '05  PHI, REI & WHO COLOUR BANDS');
  doc.setTextColor(...POCKET_SLATE);
  doc.setFontSize(8);
  doc.setFont('helvetica', 'normal');
  wrapPocketText(
    doc,
    'PHI = legal days from last spray to harvest. REI = hours before anyone re-enters without PPE. Continuous-harvest vegetables need ultra-short PHI products.',
    8,
    20,
    132
  );

  autoTable(doc, {
    startY: 34,
    head: [['Crop type', 'Rule of thumb']],
    body: [
      ['Brinjal, tomato, beans', 'Prefer 0–3 day PHI (Emamectin, Spinosad, pheromone traps)'],
      ['Rice, tea, potato', 'Early sprays degrade before harvest; cut late sprays ≥14 days out'],
      ['Tea plucking', 'Do not spray within 24 h of plucking unless label allows']
    ],
    theme: 'grid',
    headStyles: { fillColor: POCKET_GREEN, textColor: 255, fontSize: 7.5, fontStyle: 'bold' },
    styles: { fontSize: 7, cellPadding: 1.8, valign: 'top' },
    margin: { left: 8, right: 8 }
  });

  y = (doc as any).lastAutoTable.finalY + 6;
  doc.setFont('helvetica', 'bold');
  doc.setFontSize(9);
  doc.text('WHO hazard colour bands', 8, y);
  autoTable(doc, {
    startY: y + 2,
    head: [['Class', 'Band', 'Action']],
    body: [
      ['Ia / Ib', 'Red', 'Extremely / highly hazardous — full PPE, restricted use'],
      ['II', 'Yellow', 'Moderately hazardous — gloves, mask, goggles required'],
      ['III', 'Blue', 'Slightly hazardous — still use gloves and avoid drift'],
      ['U', 'Green', 'Unlikely hazard in normal use — PPE still recommended']
    ],
    theme: 'striped',
    headStyles: { fillColor: POCKET_SLATE, textColor: 255, fontSize: 7.5, fontStyle: 'bold' },
    styles: { fontSize: 7, cellPadding: 1.8 },
    margin: { left: 8, right: 8 }
  });

  // ---------- CROP TABLES ----------
  cropsList.forEach((cropName) => {
    const matching = products.filter((p) => p.crops.includes(cropName));
    const ranked = [...matching].sort((a, b) => {
      const ra = a.resistanceRisk === 'Low' ? 0 : a.resistanceRisk === 'Medium' ? 1 : 2;
      const rb = b.resistanceRisk === 'Low' ? 0 : b.resistanceRisk === 'Medium' ? 1 : 2;
      if (a.type !== b.type) return a.type.localeCompare(b.type);
      return ra - rb;
    });
    const seen = new Set<string>();
    const compact: ChemicalProduct[] = [];
    for (const p of ranked) {
      const key = `${p.commonName}|${p.type}`;
      if (seen.has(key)) continue;
      seen.add(key);
      compact.push(p);
      if (compact.length >= 18) break;
    }

    doc.addPage();
    addPocketHeader(doc, `06  ${cropName.toUpperCase()} SPRAY TABLE`);
    doc.setTextColor(...POCKET_SLATE);
    doc.setFontSize(8);
    doc.setFont('helvetica', 'normal');
    doc.text(
      `${matching.length} registered products  ·  showing ${compact.length} unique actives  ·  ${generated}`,
      8,
      18
    );

    autoTable(doc, {
      startY: 22,
      head: [['Trade / AI', 'Type', 'Pests', 'Rate', 'MoA', 'PHI']],
      body: compact.map((p) => [
        `${p.tradeName}\n${p.commonName}`,
        p.type.replace('Insecticide', 'Ins.').replace('Fungicide', 'Fun.').replace('Herbicide', 'Herb.').replace('Miticide', 'Mit.').replace('Bio Pesticide', 'Bio'),
        p.pests.slice(0, 2).join(', '),
        p.dosageRate,
        p.moaCode || '-',
        p.phiDays != null ? `${p.phiDays}d` : '-'
      ]),
      theme: 'striped',
      headStyles: { fillColor: POCKET_GREEN, textColor: 255, fontSize: 6.5, fontStyle: 'bold' },
      styles: { fontSize: 6, cellPadding: 1.3, valign: 'top', overflow: 'linebreak' },
      columnStyles: {
        0: { cellWidth: 32, fontStyle: 'bold' },
        1: { cellWidth: 14 },
        2: { cellWidth: 36 },
        3: { cellWidth: 28 },
        4: { cellWidth: 16 },
        5: { cellWidth: 10 }
      },
      margin: { left: 8, right: 8 }
    });
  });

  // ---------- MOA ----------
  doc.addPage();
  addPocketHeader(doc, '07  MoA ROTATION QUICK CODES');
  doc.setTextColor(...POCKET_SLATE);
  doc.setFontSize(8);
  doc.setFont('helvetica', 'normal');
  wrapPocketText(
    doc,
    'Never treat successive pest generations with the same numbered group. Alternate IRAC / FRAC / HRAC codes. Multi-site fungicides (M01–M03) are resistance anchors.',
    8,
    20,
    132
  );

  autoTable(doc, {
    startY: 34,
    head: [['Code', 'Family', 'Risk', 'Rotate with']],
    body: [
      ['IRAC 1A/1B', 'Carbamates / OPs', 'High', '3A, 4A, 28 — never sequential'],
      ['IRAC 3A', 'Pyrethroids', 'High', 'Limit 1–2 sprays/season; use 6 or 28'],
      ['IRAC 4A', 'Neonicotinoids', 'High', '9B, 16, 23 for next sucking-pest gen'],
      ['IRAC 6', 'Avermectins', 'Med', 'Rotate off 6 after 2 sprays'],
      ['IRAC 28', 'Diamides', 'Med', 'Alternate with 6 or 5 for borers'],
      ['FRAC 3', 'DMI / triazoles', 'Med-High', 'Tank-mix M03 mancozeb'],
      ['FRAC 11', 'QoI / strobilurins', 'High', 'Never solo; mix multi-site'],
      ['FRAC M03', 'Mancozeb multi-site', 'Low', 'Anchor for single-site partners'],
      ['HRAC 2', 'ALS inhibitors', 'High', 'Rotate 15 / 22; do not stack ALS'],
      ['HRAC 15', 'Chloroacetamides', 'Low', 'Rice pre-em base with HRAC 2']
    ],
    theme: 'grid',
    headStyles: { fillColor: [30, 64, 175], textColor: 255, fontSize: 6.5, fontStyle: 'bold' },
    styles: { fontSize: 6.2, cellPadding: 1.5, valign: 'top' },
    columnStyles: {
      0: { cellWidth: 22, fontStyle: 'bold' },
      1: { cellWidth: 32 },
      2: { cellWidth: 18 },
      3: { cellWidth: 60 }
    },
    margin: { left: 8, right: 8 }
  });

  y = (doc as any).lastAutoTable.finalY + 8;
  doc.setFont('helvetica', 'bold');
  doc.setFontSize(9);
  doc.text('Database snapshot', 8, y);
  doc.setFont('helvetica', 'normal');
  doc.setFontSize(7.5);
  wrapPocketText(
    doc,
    `Insecticides ${typeCounts.Insecticide}  ·  Fungicides ${typeCounts.Fungicide}  ·  Herbicides ${typeCounts.Herbicide}  ·  Other ${typeCounts.Other}. Open AgriChem Pro guidebook tab for full crop PDFs and the tank calculator.`,
    8,
    y + 5,
    132
  );

  // ---------- BACK COVER ----------
  doc.addPage();
  doc.setFillColor(...POCKET_SLATE);
  doc.rect(0, 0, 148, 210, 'F');
  doc.setTextColor(255, 255, 255);
  doc.setFontSize(14);
  doc.setFont('helvetica', 'bold');
  doc.text('Before you spray', 74, 40, { align: 'center' });
  doc.setFontSize(9);
  doc.setFont('helvetica', 'normal');
  const backLines = [
    '1. Calibrate the knapsack.',
    '2. Read the label rate and PHI.',
    '3. Put on full PPE.',
    '4. Mix in W.A.L.E.S. order.',
    '5. Spray upwind, never in high wind.',
    '6. Triple-rinse and wash down.',
    '7. Log product, dose, and date.'
  ];
  backLines.forEach((line, i) => {
    doc.text(line, 74, 58 + i * 10, { align: 'center' });
  });
  doc.setFontSize(7.5);
  doc.setTextColor(148, 163, 184);
  doc.text('AgriChem Pro  ·  Pocket Book Guide', 74, 180, { align: 'center' });
  doc.text('Not a legal label. Follow DAE-registered product instructions.', 74, 188, { align: 'center' });

  const pageCount = (doc.internal as any).getNumberOfPages();
  for (let i = 2; i < pageCount; i++) {
    doc.setPage(i);
    addPocketFooter(doc, i, pageCount);
  }

  doc.save('AgriChem_Pro_Pocket_Book_Guide.pdf');
}
