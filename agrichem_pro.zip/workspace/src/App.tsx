import React, { useState, useEffect } from 'react';
import { ChemicalProduct, RegulatoryAlert } from './types';
import { PESTICIDES_DATABASE } from './data/pesticidesData';
import { INITIAL_REGULATORY_ALERTS } from './data/regulatoryAlertsData';
import { Navbar } from './components/Navbar';
import { DatabaseView } from './components/DatabaseView';
import { DosageCalculatorModal } from './components/DosageCalculatorModal';
import { ProductDetailModal } from './components/ProductDetailModal';
import { SafetyChecklistModal } from './components/SafetyChecklistModal';
import { RotationPlanner } from './components/RotationPlanner';
import { SafetyView } from './components/SafetyView';
import { Guidebook } from './components/Guidebook';
import { NotificationCenter } from './components/NotificationCenter';
import { DocumentMeta } from './components/DocumentMeta';
import { WelcomeGuide } from './components/WelcomeGuide';
import { DaeDisclaimer } from './components/DaeDisclaimer';
import { useLanguage } from './context/LanguageContext';
import { Calculator } from 'lucide-react';

export default function App() {
  const { language } = useLanguage();
  const [products] = useState<ChemicalProduct[]>(PESTICIDES_DATABASE);
  const [activeTab, setActiveTab] = useState<'database' | 'calculator' | 'rotation' | 'safety' | 'guidebook' | 'alerts'>('database');
  const [searchQuery, setSearchQuery] = useState('');

  // Modals state
  const [detailProduct, setDetailProduct] = useState<ChemicalProduct | null>(null);
  const [calcProduct, setCalcProduct] = useState<ChemicalProduct | null>(null);
  const [safetyProduct, setSafetyProduct] = useState<ChemicalProduct | null>(null);

  // Alerts & Notifications state with localStorage persistence
  const [alerts, setAlerts] = useState<RegulatoryAlert[]>(() => {
    if (typeof window !== 'undefined') {
      const saved = localStorage.getItem('agrichem_alerts');
      if (saved) {
        try {
          return JSON.parse(saved);
        } catch (e) {
          console.warn('Failed to parse alerts from storage:', e);
        }
      }
    }
    return INITIAL_REGULATORY_ALERTS;
  });

  useEffect(() => {
    if (typeof window !== 'undefined') {
      localStorage.setItem('agrichem_alerts', JSON.stringify(alerts));
    }
  }, [alerts]);

  const [showGuide, setShowGuide] = useState(false);
  const unreadAlertCount = alerts.filter((a) => !a.read).length;

  const handleMarkAlertRead = (id: string) => {
    setAlerts((prev) =>
      prev.map((a) => (a.id === id ? { ...a, read: true } : a))
    );
  };

  const handleAddCustomAlert = (alert: RegulatoryAlert) => {
    setAlerts((prev) => [alert, ...prev]);
  };

  const handleDeleteAlert = (id: string) => {
    setAlerts((prev) => prev.filter((a) => a.id !== id));
  };

  return (
    <div className="min-h-screen bg-[#f6f4ee] flex flex-col font-sans text-slate-800 selection:bg-emerald-100 selection:text-emerald-900">
      <DocumentMeta activeTab={activeTab} />
      <a
        href="#main-content"
        className="sr-only focus:not-sr-only focus:absolute focus:top-2 focus:left-2 focus:z-50 focus:px-3 focus:py-2 focus:bg-white focus:rounded-lg focus:text-sm focus:shadow"
      >
        {language === 'bn' ? 'মূল বিষয়বস্তুতে যান' : 'Skip to content'}
      </a>
      <Navbar
        activeTab={activeTab}
        setActiveTab={setActiveTab}
        searchQuery={searchQuery}
        setSearchQuery={setSearchQuery}
        unreadAlertCount={unreadAlertCount}
        onOpenAlerts={() => setActiveTab('alerts')}
        onOpenGuide={() => {
          if (typeof window !== 'undefined') {
            localStorage.removeItem('agrichem_welcome_seen');
          }
          setShowGuide(true);
        }}
        totalProductsCount={products.length}
      />

      <DaeDisclaimer onOpenGuide={() => {
        if (typeof window !== 'undefined') {
          localStorage.removeItem('agrichem_welcome_seen');
        }
        setShowGuide(true);
      }} />

      <main id="main-content" className="flex-1">
        {activeTab === 'database' && (
          <DatabaseView
            products={products}
            searchQuery={searchQuery}
            setSearchQuery={setSearchQuery}
            onSelectProduct={(p) => setDetailProduct(p)}
            onOpenCalculator={(p) => setCalcProduct(p)}
            onOpenSafety={(p) => setSafetyProduct(p)}
          />
        )}

        {activeTab === 'calculator' && (
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8 space-y-6">
            <div className="bg-white border border-slate-200 rounded-2xl p-6 shadow-xs flex flex-wrap items-center justify-between gap-4">
              <div>
                <h2 className="text-xl font-bold text-slate-900 flex items-center gap-2">
                  <Calculator className="w-5 h-5 text-teal-600" />
                  {language === 'bn' ? 'ইন্টারেক্টিভ মাঠপর্যায়ের মাত্রা ও ট্যাংক মিক্সিং স্টেশন' : 'Interactive Field Dosage & Tank Mix Station'}
                </h2>
                <p className="text-xs text-slate-500 mt-1">
                  {language === 'bn' 
                    ? 'ন্যাপস্যাক স্প্রেয়ার ট্যাংক, পানির পরিমাণ এবং জমির আয়তন অনুযায়ী নির্ভুল মাত্রা হিসাব করতে যেকোনো নিবন্ধিত বালাইনাশক নির্বাচন করুন।' 
                    : 'Select any registered chemical to calculate precise knapsack tank mix rates, water volume, and area conversions.'}
                </p>
              </div>

              <button
                onClick={() => setCalcProduct(products[0])}
                className="px-4 py-2 bg-teal-600 hover:bg-teal-700 text-white rounded-xl text-xs font-semibold shadow-xs transition cursor-pointer"
              >
                {language === 'bn' ? 'ক্যালকুলেটর ডায়ালগ খুলুন' : 'Launch Knapsack Calculator Dialog'}
              </button>
            </div>

            {/* Render calculator directly */}
            <DosageCalculatorModal
              products={products}
              selectedProduct={calcProduct || products[0]}
              onClose={() => setActiveTab('database')}
              onSelectProduct={(p) => setCalcProduct(p)}
            />
          </div>
        )}

        {activeTab === 'rotation' && (
          <RotationPlanner products={products} />
        )}

        {activeTab === 'safety' && (
          <SafetyView
            products={products}
            onOpenSafetyModal={(p) => setSafetyProduct(p)}
          />
        )}

        {activeTab === 'guidebook' && (
          <Guidebook products={products} />
        )}

        {activeTab === 'alerts' && (
          <NotificationCenter
            alerts={alerts}
            onMarkRead={handleMarkAlertRead}
            onAddCustomAlert={handleAddCustomAlert}
            onDeleteAlert={handleDeleteAlert}
          />
        )}
      </main>

      {/* Global Modals */}
      {detailProduct && (
        <ProductDetailModal
          product={detailProduct}
          onClose={() => setDetailProduct(null)}
          onOpenDosageCalculator={(p) => {
            setDetailProduct(null);
            setCalcProduct(p);
          }}
        />
      )}

      {calcProduct && activeTab !== 'calculator' && (
        <DosageCalculatorModal
          products={products}
          selectedProduct={calcProduct}
          onClose={() => setCalcProduct(null)}
          onSelectProduct={(p) => setCalcProduct(p)}
        />
      )}

      {safetyProduct && (
        <SafetyChecklistModal
          product={safetyProduct}
          onClose={() => setSafetyProduct(null)}
        />
      )}

      {/* Footer */}
      <footer className="bg-white border-t border-slate-200 mt-12 py-8 text-xs text-slate-500">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 flex flex-col sm:flex-row items-center justify-between gap-4">
          <div className="flex items-center gap-3">
            <img
              src="/logo.svg"
              alt={language === 'bn' ? 'এগ্রিকেম প্রো লোগো' : 'AgriChem Pro logo'}
              width={32}
              height={32}
              className="w-8 h-8 rounded-lg"
            />
            <div>
              <p className="font-bold text-slate-900">
                {language === 'bn' ? 'অ্যাগ্রিকেম প্রো — ফিল্ড কন্ট্রোলস ও ডাটাবেস গাইডবুক' : 'AgriChem Pro — Field Controls & Database Guidebook'}
              </p>
              <p className="text-[11px] text-slate-500">
                {language === 'bn'
                  ? 'জ্ঞান ভাগাভাগি · চূড়ান্ত পরামর্শ নিন DAE বা উপজেলা কৃষি কর্মকর্তার কাছ থেকে'
                  : 'Knowledge sharing · Take final advice from DAE or your local extension officer'}
              </p>
            </div>
          </div>

          <div className="flex flex-wrap items-center gap-4 text-xs">
            <button onClick={() => setActiveTab('database')} className="hover:text-emerald-700 cursor-pointer">
              {language === 'bn' ? 'রাসায়নিক ডিরেক্টরি' : 'Chemical Directory'}
            </button>
            <button onClick={() => setActiveTab('rotation')} className="hover:text-emerald-700 cursor-pointer">
              {language === 'bn' ? 'MoA ঘূর্ণন' : 'MoA Rotation'}
            </button>
            <button onClick={() => setActiveTab('safety')} className="hover:text-emerald-700 cursor-pointer">
              {language === 'bn' ? 'পিপিই চেকলিস্ট' : 'PPE Checklists'}
            </button>
            <button onClick={() => setActiveTab('guidebook')} className="hover:text-emerald-700 cursor-pointer">
              {language === 'bn' ? 'ফিল্ড ক্যালিব্রেশন' : 'Field Calibration'}
            </button>
            <button onClick={() => setActiveTab('alerts')} className="hover:text-emerald-700 cursor-pointer">
              {language === 'bn' ? 'নিয়ন্ত্রক নোটিফিকেশন' : 'Compliance Alerts'}
            </button>
          </div>
        </div>
        <p className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 mt-5 pt-4 border-t border-slate-100 text-[11px] leading-relaxed text-slate-500">
          {language === 'bn'
            ? 'ডিসক্লেইমার: এই অ্যাপ শিক্ষামূলক। এটি সরকারি আদেশ বা নিবন্ধিত লেবেলের বিকল্প নয়। স্প্রে করার আগে পণ্যের লেবেল পড়ুন এবং কৃষি সম্প্রসারণ অধিদপ্তর (DAE)-এর সর্বশেষ নির্দেশনা অনুসরণ করুন।'
            : 'Disclaimer: This app is educational. It does not replace official orders or the registered label. Read the product label and follow the latest Department of Agricultural Extension (DAE) guidance before any spray.'}
        </p>
      </footer>
      <WelcomeGuide
        forceOpen={showGuide}
        onDismiss={() => setShowGuide(false)}
        onGo={(tab) => {
          setShowGuide(false);
          setActiveTab(tab);
        }}
      />
    </div>
  );
}
